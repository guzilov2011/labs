from django.apps import AppConfig


class Lab5AppConfig(AppConfig):
    name = 'Lab5_App'
